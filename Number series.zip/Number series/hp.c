#include<stdio.h>
int main(){
    int a;
    scanf("%d",&a);
    printf("1");
    for(int i = 2;i<a;i++){
        printf(" + 1/%d",i);
    }
}