#include<stdio.h>
int main(){
    int a,i,sum=0;
    scanf("%d",&a);
    for(i=1;i<=a;i++){
        printf("%d ",i*i*i);
        sum +=(i*i*i);
    }
    printf("\nsum is %d",sum);
}