#include<stdio.h>
int main(){
    int n,i;
    float sum=0;
    scanf("%d",&n);
    for(i=1;i<n;i++){
        int term = 1;
        printf("diff: %d",term);
        sum = sum+term;
    }
    
    printf("\nsum is %d",sum);

}