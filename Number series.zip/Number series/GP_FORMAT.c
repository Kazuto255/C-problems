#include<stdio.h>
#include<math.h>
int main(){
    int a,r,n,i,sum=0;
    scanf("%d%d%d",&a,&n,&r);
    for(i=0;i<n;i++){
        int term = a*pow(r,i);
        printf("%d ",term);
        sum = sum + term;
        }printf("\nsum is %d",sum);
    }
