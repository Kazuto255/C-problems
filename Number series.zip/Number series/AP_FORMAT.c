#include<stdio.h>
int main(){
    int a,n,d,sum=0,i;
    scanf("%d%d%d",&a,&n,&d);
    for(i=1;i<n;i++){
        int term = a+(i*d);
        printf("diff: %d",term);
        sum = sum+term;
    }
    
    printf("\nsum is %d",sum);

}// DOUBT DO AGAIN