#include<stdio.h>
int main(){
    int n,sum=0,i;
    scanf("%d",&n);
    for(i=1;i<n;i++){
      if(n%i==0){
        sum += i;
        }
    }
    printf("%d ",sum);
    if(sum == n)
    printf("Perfect Number\n");
    else
    printf("Not a perfect Number\n");
}