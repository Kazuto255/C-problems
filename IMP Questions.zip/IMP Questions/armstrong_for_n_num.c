#include<stdio.h>
#include<math.h>
int main(){
    int a,n,b,sum=0;
    scanf("%d %d",&a,&n);
    int temp = a;
    while(a>0){
        b = a%10;
        sum += pow(b,n);
        a = a/10;
    }
    if(a==temp){
        printf("%d is armstrong",temp);
    }else{
        printf("%d is not arms",temp);
    }

}