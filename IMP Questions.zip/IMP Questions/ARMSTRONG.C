#include<stdio.h>
int main()
{
    int a,sum=0,l;
    scanf("%d",&a);
    int temp = a;
    while(a>0)
    {
        l = a%10;
        sum = sum + (l*l*l);
        a = a/10;
    }
    if(sum == temp)
        {
            printf("Armstrong number");
            
        }else
        {
            printf("Not a Armstrong number");
            
        }
    return 0;
}