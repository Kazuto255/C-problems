/***********************************************/
/*            PASCAL'S TRIANGLE                */
/***********************************************/
#include<stdio.h>
int main()
{
    int a =1,i,n,row;
    int sum;

    printf("Enter number of rows : ");
    scanf(" %d",&n);
    for(row = 1;row<=n;row++)
    {
        a = 1;
        for(i =1;i<=row;i++)
        {
            printf("  %d ",a);
            a = a * (row-i) / i;
        }
        printf("\n");
    }   
    return 0;
}