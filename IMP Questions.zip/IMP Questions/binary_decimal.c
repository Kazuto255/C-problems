#include<stdio.h>
#include<math.h>
int main(){
    int a,decimal=0,i=0;
    scanf("%d",&a);
    while(a!=0){
        int digit = a % 10;
        decimal = decimal +(digit * pow(2,i));
        i++;
         a /= 10;
    }
        printf("decimal: %d",decimal);
}