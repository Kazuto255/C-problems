#include<stdio.h>
void main()
{
  int i,n,f[10],rem;
  scanf("%d",&n);
  while(n!=0)
  {
    rem=n%10;
    f[rem]++;
    n=n/10;
  }
  for(i=0;i<10;i++)
    printf("%d ",f[i]);
}