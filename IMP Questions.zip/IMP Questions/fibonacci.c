/*             Fibonacci series        */
#include<stdio.h>
int main()
{
    int first=0 ,sec=1, nxterm, i, n;

    printf("Enter a number = ");
    scanf(" %d",&n);
    for(i = 1; i <= n; i++)
        {
           printf("%d ",first);
            nxterm = first + sec;
            first = sec;
            sec = nxterm;

        }
        return 0 ;

}