/*#include<stdio.h>
int mul();
    int a,b;
void main(){
    scanf("%d%d",&a,&b);
    //int result = mul();
    printf("%d * %d = %d",a,b,mul());
}
int mul(){
    int mul=1;
    //scanf("%d%d",&a,&b);
    mul = a*b;
    return mul;

}*/
#include<stdio.h>
void multi();
void main(){
    multi();
    multi();
}
void multi(){
    int a,b,c;
    scanf("%d%d",&a,&b);
    c=a*b;
    printf("%d",c);
    return c;
}