//Condition-1   (NO ARGUMENT AND NO RETURN)
/*
#include<stdio.h>
void main(){
    sum();
    sum();
    sum();
    return 0;
}
void sum(){
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d",a+b);
    printf("%d",a-b);
}*/
//Condition--3 (ARGUMENT AND NO RETURN)
/*
#include<stdio.h>
void sum();
void main(){
    int x,y;
    scanf("%d%d",&x,&y);
    sum(x,y);
    scanf("%d%d",&x,&y);
    sum(x,y);
}
void sum(int x,int y){
    printf("%d\n",x+y);
    printf("%d\n",x-y);
}*/
//Condition--2  {NO ARGUMENT AND RETURN TYPE}

#include<stdio.h>
int sum();
int diff();
void main(){
    int r=sum();
    int d=diff();
    printf("sum=%d",r);
    printf("\ndiff=%d",d);
}
int sum(){
    int a,b,sum=0,diff=0;
    scanf("%d%d",&a,&b);
    sum=a+b;

    return sum;
}
int diff(){
    int a,b,diff=0;
    scanf("%d%d",&a,&b);
    diff=a-b;
    return diff;
}

//Condition -- 4
/*
#include<stdio.h>
int sum();
float diff();
void main(){
    int a,b,result;
    float total;
    scanf("%d%d",&a,&b);
    result = sum(a,b);
    total  = diff(a,b);
    printf("Sum is %d\n",result);
    printf("diff is %f",total);
}
int sum(int a, int b){
    int sum = 0;
    sum = a+b;
    return sum;
}
float diff(int a,int b){
    int diff=0;
    diff = a-b;
    return diff;
}
*/

