#include<stdio.h>// ascii value of letter to number.
void position();
void main(){
  position();
  
}
void position(){
  char a;
  int b,i;
  scanf("%c",&a);
  i = a;
  if(i >= 'a' && i <= 'z'){
    b=a-'a'+1;
  }else if(i>= 'A' && i <= 'Z'){
    b = a-'A'+1;
  }
  printf("%d\n",b);
}